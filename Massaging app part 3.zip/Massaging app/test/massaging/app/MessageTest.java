package massaging.app;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "Message ready to send.",
                msg.checkMessageLength()
        );
    }

    @Test
    public void testMessageLengthFailure() {

        String longMessage =
                "a".repeat(260);

        Message msg = new Message(
                1,
                "+27718693002",
                longMessage
        );

        assertEquals(
                "Message exceeds 250 characters by 10, please reduce size.",
                msg.checkMessageLength()
        );
    }

    @Test
    public void testRecipientSuccess() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertTrue(
                msg.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientFail() {

        Message msg = new Message(
                1,
                "087123456",
                "Hello"
        );

        assertFalse(
                msg.checkRecipientCell()
        );
    }

    @Test
    public void testMessageID() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertTrue(
                msg.checkMessageID()
        );
    }

    @Test
    public void testMessageHash() {

        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike"
        );

        assertTrue(
                msg.getMessageHash()
                        .contains("HIMIKE")
        );
    }

    @Test
    public void testSendMessage() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Message successfully sent.",
                msg.SentMessage(1)
        );
    }

    @Test
    public void testStoreMessage() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Hello"
        );

        assertEquals(
                "Message successfully stored.",
                msg.SentMessage(3)
        );
    }

    @Test
    public void testSearchByMessageID() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Search Test"
        );

        msg.SentMessage(1);

        Message found =
                Message.searchByMessageID(
                        msg.getMessageID()
                );

        assertNotNull(found);
    }

    @Test
    public void testSearchByRecipient() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Recipient Test"
        );

        msg.SentMessage(1);

        ArrayList<Message> results =
                Message.searchByRecipient(
                        "+27718693002"
                );

        assertFalse(results.isEmpty());
    }

    @Test
    public void testDeleteByHash() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Delete Test"
        );

        msg.SentMessage(1);

        boolean deleted =
                Message.deleteByHash(
                        msg.getMessageHash()
                );

        assertTrue(deleted);
    }

    @Test
    public void testLongestMessage() {

        Message msg1 = new Message(
                1,
                "+27718693002",
                "Hi"
        );

        Message msg2 = new Message(
                2,
                "+27718693002",
                "This is the longest stored message in the test."
        );

        msg1.SentMessage(3);
        msg2.SentMessage(3);

        Message longest =
                Message.getLongestMessage();

        assertNotNull(longest);
    }

    @Test
    public void testTotalMessages() {

        Message msg1 = new Message(
                1,
                "+27718693002",
                "Message One"
        );

        Message msg2 = new Message(
                2,
                "+27718693003",
                "Message Two"
        );

        msg1.SentMessage(1);
        msg2.SentMessage(1);

        assertTrue(
                Message.returnTotalMessages() >= 2
        );
    }

    @Test
    public void testStoredMessages() {

        Message msg = new Message(
                1,
                "+27718693002",
                "Stored Message"
        );

        msg.SentMessage(3);

        assertTrue(
                Message.returnStoredMessages() >= 1
        );
    }
}