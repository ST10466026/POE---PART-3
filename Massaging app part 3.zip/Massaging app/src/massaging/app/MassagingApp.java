package massaging.app;

import java.util.ArrayList;
import java.util.Scanner;

public class MassagingApp {

public static void main(String[] args) {

    Scanner input = new Scanner(System.in);

    Login login = new Login();

    System.out.println("=== REGISTER ===");

    System.out.print("Enter first name: ");
    String firstName = input.nextLine();

    System.out.print("Enter surname: ");
    String surname = input.nextLine();

    System.out.print("Enter username: ");
    String username = input.nextLine();

    System.out.print("Enter password: ");
    String password = input.nextLine();

    System.out.print("Enter cellphone (+27): ");
    String phone = input.nextLine();

    String register = login.registerUser(
            firstName,
            surname,
            username,
            password,
            phone
    );

    System.out.println(register);

    if (!register.equals("User successfully registered.")) {
        return;
    }

    System.out.println("\n=== LOGIN ===");

    boolean loggedIn = false;

    while (!loggedIn) {

        System.out.print("Enter username: ");
        String loginUser = input.nextLine();

        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        loggedIn = login.loginUser(
                loginUser,
                loginPass
        );

        System.out.println(
                login.returnLoginStatus(loggedIn)
        );
    }

    System.out.println("\nWelcome to QuickChat.");

    System.out.print("How many messages would you like to send? ");
    int numMessages = Integer.parseInt(input.nextLine());

    int sentCount = 0;

    while (true) {

        System.out.println("""
                
                1) Send Messages
                2) Show Sent Messages
                3) Show Stored Messages
                4) Search Message by ID
                5) Search Messages by Recipient
                6) Delete Message by Hash
                7) Display Longest Stored Message
                8) Display Report
                9) Quit
                """);

        System.out.print("Choose option: ");
        int option = Integer.parseInt(input.nextLine());

        switch (option) {

            case 1:

                if (sentCount >= numMessages) {

                    System.out.println(
                            "You have reached your message limit."
                    );
                    break;
                }

                System.out.print("Enter recipient (+27): ");
                String recipient = input.nextLine();

                System.out.print("Enter message: ");
                String text = input.nextLine();

                Message message =
                        new Message(
                                sentCount + 1,
                                recipient,
                                text
                        );

                System.out.println(
                        message.checkMessageLength()
                );

                if (!message.checkRecipientCell()) {

                    System.out.println(
                            "Cell phone number incorrectly formatted."
                    );

                    break;
                }

                System.out.println(
                        "Cell phone number successfully captured."
                );

                System.out.println(
                        "Message Hash: "
                        + message.getMessageHash()
                );

                System.out.println("""
                        
                        1) Send Message
                        2) Disregard Message
                        3) Store Message
                        """);

                System.out.print("Choose: ");
                int sendOption =
                        Integer.parseInt(
                                input.nextLine()
                        );

                System.out.println(
                        message.SentMessage(sendOption)
                );

                sentCount++;

                break;

            case 2:

                System.out.println(
                        Message.printMessages()
                );

                break;

            case 3:

                System.out.println(
                        Message.printStoredMessages()
                );

                break;

            case 4:

                System.out.print(
                        "Enter Message ID: "
                );

                String id =
                        input.nextLine();

                Message found =
                        Message.searchByMessageID(id);

                if (found != null) {

                    System.out.println(found);

                } else {

                    System.out.println(
                            "Message not found."
                    );
                }

                break;

            case 5:

                System.out.print(
                        "Enter recipient: "
                );

                String searchRecipient =
                        input.nextLine();

                ArrayList<Message> results =
                        Message.searchByRecipient(
                                searchRecipient
                        );

                if (results.isEmpty()) {

                    System.out.println(
                            "No messages found."
                    );

                } else {

                    for (Message msg : results) {

                        System.out.println(msg);
                    }
                }

                break;

            case 6:

                System.out.print(
                        "Enter Message Hash: "
                );

                String hash =
                        input.nextLine();

                if (Message.deleteByHash(hash)) {

                    System.out.println(
                            "Message deleted."
                    );

                } else {

                    System.out.println(
                            "Hash not found."
                    );
                }

                break;

            case 7:

                Message longest =
                        Message.getLongestMessage();

                if (longest != null) {

                    System.out.println(
                            longest
                    );

                } else {

                    System.out.println(
                            "No stored messages."
                    );
                }

                break;

            case 8:

                Message.displayReport();

                break;

            case 9:

                System.out.println(
                        "Total messages sent: "
                        + Message.returnTotalMessages()
                );

                System.out.println(
                        "Total stored messages: "
                        + Message.returnStoredMessages()
                );

                System.out.println(
                        "Goodbye."
                );

                System.exit(0);

                break;

            default:

                System.out.println(
                        "Invalid option."
                );
        }
    }
}


}
