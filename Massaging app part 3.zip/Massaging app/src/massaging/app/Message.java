package massaging.app;

import java.util.ArrayList;
import java.util.Random;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;

    private static ArrayList<Message> sentMessages =
            new ArrayList<>();

    private static ArrayList<Message> storedMessages =
            new ArrayList<>();

    public Message(
            int messageNumber,
            String recipient,
            String message) {

        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;

        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {

        Random random = new Random();

        long number =
                1000000000L
                + (long) (random.nextDouble()
                * 9000000000L);

        return String.valueOf(number);
    }

    public boolean checkMessageID() {

        return messageID.length() == 10;
    }

    public boolean checkRecipientCell() {

        return recipient != null
                && recipient.matches("^\\+27\\d{9}$");
    }

    public String createMessageHash() {

        String[] words = message.trim().split("\\s+");

        String firstWord =
                words[0].toUpperCase();

        String lastWord =
                words[words.length - 1].toUpperCase();

        return messageID.substring(0, 2)
                + ":"
                + messageNumber
                + ":"
                + firstWord
                + lastWord;
    }

    public String checkMessageLength() {

        if (message.length() <= 250) {

            return "Message ready to send.";
        }

        int extra = message.length() - 250;

        return "Message exceeds 250 characters by "
                + extra
                + ", please reduce size.";
    }

    public String SentMessage(int option) {

        switch (option) {

            case 1:

                sentMessages.add(this);

                return "Message successfully sent.";

            case 2:

                return "Message disregarded.";

            case 3:

                storedMessages.add(this);

                return "Message successfully stored.";

            default:

                return "Invalid option.";
        }
    }

    public static String printMessages() {

        StringBuilder result =
                new StringBuilder();

        for (Message msg : sentMessages) {

            result.append(msg.toString())
                    .append("\n\n");
        }

        return result.toString();
    }

    public static String printStoredMessages() {

        StringBuilder result =
                new StringBuilder();

        for (Message msg : storedMessages) {

            result.append(msg.toString())
                    .append("\n\n");
        }

        return result.toString();
    }

    public static int returnTotalMessages() {

        return sentMessages.size();
    }

    public static int returnStoredMessages() {

        return storedMessages.size();
    }

    public static Message searchByMessageID(
            String id) {

        for (Message msg : sentMessages) {

            if (msg.getMessageID().equals(id)) {

                return msg;
            }
        }

        for (Message msg : storedMessages) {

            if (msg.getMessageID().equals(id)) {

                return msg;
            }
        }

        return null;
    }

    public static ArrayList<Message> searchByRecipient(
            String recipient) {

        ArrayList<Message> results =
                new ArrayList<>();

        for (Message msg : sentMessages) {

            if (msg.getRecipient()
                    .equals(recipient)) {

                results.add(msg);
            }
        }

        for (Message msg : storedMessages) {

            if (msg.getRecipient()
                    .equals(recipient)) {

                results.add(msg);
            }
        }

        return results;
    }

    public static boolean deleteByHash(
            String hash) {

        for (Message msg : sentMessages) {

            if (msg.getMessageHash()
                    .equals(hash)) {

                sentMessages.remove(msg);

                return true;
            }
        }

        for (Message msg : storedMessages) {

            if (msg.getMessageHash()
                    .equals(hash)) {

                storedMessages.remove(msg);

                return true;
            }
        }

        return false;
    }

    public static Message getLongestMessage() {

        Message longest = null;

        for (Message msg : storedMessages) {

            if (longest == null
                    || msg.getMessage().length()
                    > longest.getMessage().length()) {

                longest = msg;
            }
        }

        return longest;
    }

    public static void displayReport() {

        System.out.println(
                "\n===== MESSAGE REPORT =====");

        for (Message msg : storedMessages) {

            System.out.println(
                    "Message Hash: "
                    + msg.getMessageHash());

            System.out.println(
                    "Recipient: "
                    + msg.getRecipient());

            System.out.println(
                    "Message: "
                    + msg.getMessage());

            System.out.println(
                    "--------------------------------");
        }
    }

    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }

    @Override
    public String toString() {

        return "Message ID: "
                + messageID
                + "\nMessage Hash: "
                + messageHash
                + "\nRecipient: "
                + recipient
                + "\nMessage: "
                + message;
    }
}