package massaging.app;

public class Login {

    private String storedFirstName;
    private String storedSurname;
    private String storedUsername;
    private String storedPassword;
    private String storedPhone;

    public boolean checkUserName(String username) {

        if (username == null) {
            return false;
        }

        return username.contains("_")
                && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUpper = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {

            if (Character.isUpperCase(c)) {
                hasUpper = true;
            }

            if (Character.isDigit(c)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        return hasUpper
                && hasNumber
                && hasSpecial;
    }

    public boolean checkCellPhoneNumber(String phone) {

        if (phone == null) {
            return false;
        }

        return phone.matches("^\\+27\\d{9}$");
    }

    public String registerUser(
            String firstName,
            String surname,
            String username,
            String password,
            String phone) {

        if (!checkUserName(username)) {

            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(password)) {

            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(phone)) {

            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        storedFirstName = firstName.trim();
        storedSurname = surname.trim();
        storedUsername = username.trim();
        storedPassword = password.trim();
        storedPhone = phone.trim();

        return "User successfully registered.";
    }

    public boolean loginUser(
            String username,
            String password) {

        if (username == null
                || password == null
                || storedUsername == null
                || storedPassword == null) {

            return false;
        }

        return username.trim().equals(storedUsername)
                && password.trim().equals(storedPassword);
    }

    public String returnLoginStatus(boolean success) {

        if (success) {

            return "Welcome "
                    + storedFirstName
                    + " "
                    + storedSurname
                    + ", it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }

    public String getStoredFirstName() {
        return storedFirstName;
    }

    public String getStoredSurname() {
        return storedSurname;
    }

    public String getStoredUsername() {
        return storedUsername;
    }

    public String getStoredPassword() {
        return storedPassword;
    }

    public String getStoredPhone() {
        return storedPhone;
    }

    public void setStoredFirstName(String storedFirstName) {
        this.storedFirstName = storedFirstName;
    }

    public void setStoredSurname(String storedSurname) {
        this.storedSurname = storedSurname;
    }

    public void setStoredUsername(String storedUsername) {
        this.storedUsername = storedUsername;
    }

    public void setStoredPassword(String storedPassword) {
        this.storedPassword = storedPassword;
    }

    public void setStoredPhone(String storedPhone) {
        this.storedPhone = storedPhone;
    }
}